function Dashboard({ onNavigate, loggedIn }) {
  const { Header, Footer, Button, MemoryCard } = window.Svitlyachok;
  const [filter, setFilter] = React.useState("all");

  const items = [
    { title: "Смак ірисок з бабусиної кухні", excerpt: "Щоліта бабуся варила ці цукерки на плиті...", author: "Оксана", city: "Полтава", topic: "Бабусині рецепти", warmth: 12, comments: 3, privacy: "public" },
    { title: "Лист до себе у 10 років", excerpt: "Я написала цей лист і сховала в шафі — знайшла лише зараз.", author: "Оксана", city: "Полтава", topic: "Дворові ігри", warmth: 0, comments: 0, privacy: "private" },
    { title: "Рецепт борщу від бабусі Галі", excerpt: "Записала все, поки вона ще пам'ятає точні пропорції.", author: "Оксана", city: "Полтава", topic: "Бабусині рецепти", warmth: 4, comments: 1, privacy: "public" },
  ];
  const filtered = items.filter((i) => filter === "all" || i.privacy === filter);
  const tabs = [{ v: "all", l: "Усі" }, { v: "public", l: "Публічні" }, { v: "private", l: "Тільки я" }];

  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100%", background: "var(--bg-page)" }}>
      <Header loggedIn={loggedIn} userName="Оксана" onNavigate={onNavigate} />
      <div style={{ maxWidth: "var(--content-max)", margin: "0 auto", width: "100%", padding: "var(--space-8) var(--gutter)", flex: 1 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12 }}>
          <div>
            <h1 style={{ fontFamily: "var(--font-heading)", fontSize: "var(--text-h1)", marginBottom: 4 }}>Мої світлячки</h1>
            <p style={{ color: "var(--text-secondary)" }}>Ваш особистий архів спогадів.</p>
          </div>
          <Button variant="primary" onClick={() => onNavigate("create")}>+ Новий спогад</Button>
        </div>

        <div style={{ display: "flex", gap: 2, background: "var(--bg-sunken)", borderRadius: "var(--radius-pill)", padding: 3, width: "fit-content", margin: "var(--space-6) 0" }}>
          {tabs.map((t) => (
            <button key={t.v} onClick={() => setFilter(t.v)} style={{
              border: "none", cursor: "pointer", padding: "7px 16px", borderRadius: "var(--radius-pill)", fontSize: 13, fontWeight: 600,
              background: filter === t.v ? "var(--bg-surface)" : "transparent",
              color: filter === t.v ? "var(--text-primary)" : "var(--text-tertiary)",
              boxShadow: filter === t.v ? "var(--shadow-sm)" : "none",
            }}>{t.l}</button>
          ))}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 20 }}>
          {filtered.map((it) => (
            <MemoryCard key={it.title} {...it} onClick={() => onNavigate("memory")} />
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
}
