function About({ onNavigate, loggedIn }) {
  const { Header, Footer } = window.Svitlyachok;
  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100%", background: "var(--bg-page)" }}>
      <Header loggedIn={loggedIn} userName="Оксана" onNavigate={onNavigate} />
      <div style={{ maxWidth: "var(--content-narrow)", margin: "0 auto", width: "100%", padding: "var(--space-16) var(--gutter)", flex: 1, display: "flex", flexDirection: "column", gap: 20 }}>
        <h1 style={{ fontFamily: "var(--font-heading)", fontSize: "var(--text-h1)" }}>Про проєкт</h1>
        <p style={{ fontSize: "var(--text-body-lg)", lineHeight: "var(--lh-body)", color: "var(--text-primary)" }}>
          Світлячок — спільнота для дорослих, присвячена дитинству, родині та добру.
          Тут можна зберегти власні спогади, прочитати теплі історії інших людей
          за темами й містами, а також спробувати знайти фото чи відео, втрачені
          через війну або переїзд.
        </p>
        <p style={{ fontSize: "var(--text-body)", lineHeight: "var(--lh-body)", color: "var(--text-secondary)" }}>
          Реєстрація не потрібна, щоб переглядати стрічку чи розділ «Загублені
          світлячки». Вона потрібна лише тоді, коли ви хочете щось зберегти чи
          опублікувати. Публічність — це вибір, а не обов'язок: більшість спогадів
          залишаються особистими, доки ви самі не вирішите поділитися.
        </p>
        <p style={{ fontSize: "var(--text-body)", lineHeight: "var(--lh-body)", color: "var(--text-secondary)" }}>
          Ми не женемося за лайками чи охопленнями. Це місце для того, щоб
          зберегти своє світло — і, за бажанням, побачити світло інших.
        </p>
      </div>
      <Footer />
    </div>
  );
}
