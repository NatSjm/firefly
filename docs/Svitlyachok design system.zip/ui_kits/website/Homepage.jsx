function Homepage({ onNavigate, onLogin, loggedIn }) {
  const { Header, Footer, Button, MemoryCard, Badge } = window.Svitlyachok;
  const topics = ["Океан Ельзи", "Бабусині рецепти", "Комп'ютерні ігри", "Тамагочі", "Дворові ігри"];
  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100%", background: "var(--bg-page)" }}>
      <Header loggedIn={loggedIn} userName="Оксана" onNavigate={onNavigate} onLogin={onLogin} />

      <section style={{
        display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center",
        gap: 20, padding: "var(--space-24) var(--gutter) var(--space-16)",
      }}>
        <img src="../../assets/firefly-mark.svg" width="72" height="72" alt="" />
        <h1 style={{ fontFamily: "var(--font-heading)", fontSize: "var(--text-display)", lineHeight: "var(--lh-display)", maxWidth: 720 }}>
          Світлячок
        </h1>
        <p style={{ fontFamily: "var(--font-body)", fontSize: "var(--text-body-lg)", color: "var(--text-secondary)", maxWidth: 560, lineHeight: "var(--lh-body)" }}>
          Місце, де можна зберегти теплі спогади про дитинство, родину і людей,
          яких любите — і, за бажанням, поділитися ними з іншими.
        </p>
        <div style={{ display: "flex", gap: 12, marginTop: 8, flexWrap: "wrap", justifyContent: "center" }}>
          <Button variant="primary" onClick={() => onNavigate("create")}>Зберегти перший спогад</Button>
          <Button variant="secondary" onClick={() => onNavigate("feed")}>Переглянути стрічку</Button>
        </div>
      </section>

      <section style={{ padding: "var(--space-4) var(--gutter) var(--space-16)", maxWidth: "var(--content-max)", margin: "0 auto", width: "100%" }}>
        <h2 style={{ fontFamily: "var(--font-heading)", fontSize: "var(--text-h3)", marginBottom: 16 }}>Останні спогади</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 20 }}>
          <MemoryCard title="Смак ірисок з бабусиної кухні" excerpt="Щоліта бабуся варила ці цукерки на плиті, а ми з сестрою чекали під дверима."
            author="Оксана" city="Полтава" topic="Бабусині рецепти" warmth={12} comments={3} privacy="public" onClick={() => onNavigate("memory")} />
          <MemoryCard title="Тамагочі, який пережив три школи" excerpt="Я носив його в кишені навіть на контрольні — вчителька вдавала, що не бачить."
            author="Максим" city="Харків" topic="Тамагочі" warmth={27} comments={8} privacy="public" onClick={() => onNavigate("memory")} />
          <MemoryCard title="Двір на вулиці Шевченка" excerpt="Кожного вечора ми грали у класики, доки не темніло і не кликали додому."
            author="Ірина" city="Київ" topic="Дворові ігри" warmth={9} comments={2} privacy="public" onClick={() => onNavigate("memory")} />
        </div>
      </section>

      <section style={{ padding: "0 var(--gutter) var(--space-20)", maxWidth: "var(--content-max)", margin: "0 auto", width: "100%" }}>
        <h2 style={{ fontFamily: "var(--font-heading)", fontSize: "var(--text-h3)", marginBottom: 16 }}>Пошук за темами</h2>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          {topics.map((t, i) => (
            <Badge key={t} variant="topic" tone={i % 2 === 0 ? "amber" : "moss"}>{t}</Badge>
          ))}
        </div>
      </section>

      <Footer />
    </div>
  );
}
