function Feed({ onNavigate, loggedIn }) {
  const { Header, Footer, FilterBar, MemoryCard } = window.Svitlyachok;
  const [city, setCity] = React.useState("");
  const [topic, setTopic] = React.useState("");
  const [sort, setSort] = React.useState("new");

  const items = [
    { title: "Смак ірисок з бабусиної кухні", excerpt: "Щоліта бабуся варила ці цукерки на плиті...", author: "Оксана", city: "Полтава", topic: "Бабусині рецепти", warmth: 12, comments: 3 },
    { title: "Тамагочі, який пережив три школи", excerpt: "Я носив його в кишені навіть на контрольні...", author: "Максим", city: "Харків", topic: "Тамагочі", warmth: 27, comments: 8 },
    { title: "Двір на вулиці Шевченка", excerpt: "Кожного вечора ми грали у класики...", author: "Ірина", city: "Київ", topic: "Дворові ігри", warmth: 9, comments: 2 },
    { title: "Перший диск Океану Ельзи", excerpt: "Тато привіз касету з Києва, і ми слухали її щодня...", author: "Андрій", city: "Львів", topic: "Океан Ельзи", warmth: 15, comments: 5 },
    { title: "Найкращий рахунок у Діггера", excerpt: "Комп'ютерний клуб на розі був цілим світом...", author: "Сергій", city: "Одеса", topic: "Комп'ютерні ігри", warmth: 6, comments: 1 },
    { title: "Вареники з вишнями від мами", excerpt: "Влітку ми ліпили їх усією родиною на кухні...", author: "Наталя", city: "Дніпро", topic: "Бабусині рецепти", warmth: 19, comments: 4 },
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100%", background: "var(--bg-page)" }}>
      <Header loggedIn={loggedIn} userName="Оксана" onNavigate={onNavigate} />
      <div style={{ maxWidth: "var(--content-max)", margin: "0 auto", width: "100%", padding: "var(--space-8) var(--gutter)", flex: 1 }}>
        <h1 style={{ fontFamily: "var(--font-heading)", fontSize: "var(--text-h1)", marginBottom: 4 }}>Стрічка спогадів</h1>
        <p style={{ color: "var(--text-secondary)", marginBottom: 8 }}>Теплі історії від людей з усієї України.</p>
        <FilterBar city={city} onCityChange={(e) => setCity(e.target.value)} topic={topic} onTopicChange={(e) => setTopic(e.target.value)} sort={sort} onSortChange={setSort} />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 20, marginTop: 8 }}>
          {items.map((it) => (
            <MemoryCard key={it.title} {...it} privacy="public" onClick={() => onNavigate("memory")} />
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
}
