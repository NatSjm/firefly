function LostFireflies({ onNavigate, loggedIn }) {
  const { Header, Footer, Button, LostRequestCard, FilterBar, Field, TextInput, Textarea, Select } = window.Svitlyachok;
  const [showForm, setShowForm] = React.useState(false);
  const [city, setCity] = React.useState("");

  const requests = [
    { city: "Маріуполь", type: "school", years: "1998–2005", description: "Шукаю фото випускного 9-го класу, школа №33.", author: "Ігор", date: "3 дні тому" },
    { city: "Донецьк", type: "kindergarten", years: "1990–1993", description: "Груповий знімок дитсадка №12, група «Сонечко».", author: "Марина", date: "тиждень тому" },
    { city: "Луганськ", type: "camp", years: "1996", description: "Фото з табору «Зірка» на березі річки, літня зміна.", author: "Дмитро", date: "2 тижні тому" },
    { city: "Херсон", type: "yard", years: "2001–2004", description: "Компанія з двору на Таврійському, шукаю будь-які спільні фото.", author: "Аліна", date: "місяць тому" },
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100%", background: "var(--bg-page)" }}>
      <Header loggedIn={loggedIn} userName="Оксана" onNavigate={onNavigate} />
      <div style={{ maxWidth: "var(--content-max)", margin: "0 auto", width: "100%", padding: "var(--space-8) var(--gutter)", flex: 1 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12 }}>
          <div style={{ maxWidth: 560 }}>
            <h1 style={{ fontFamily: "var(--font-heading)", fontSize: "var(--text-h1)", marginBottom: 4 }}>Загублені світлячки</h1>
            <p style={{ color: "var(--text-secondary)" }}>Фото і відео дитинства, втрачені через війну чи переїзд, іноді знаходяться завдяки іншим людям.</p>
          </div>
          <Button variant="primary" onClick={() => setShowForm((v) => !v)}>{showForm ? "Сховати форму" : "Створити запит"}</Button>
        </div>

        {showForm && (
          <div style={{ background: "var(--bg-surface-alt)", borderRadius: "var(--radius-lg)", padding: "var(--space-6)", margin: "var(--space-6) 0", display: "flex", flexDirection: "column", gap: 16, maxWidth: 520 }}>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
              <div style={{ flex: 1, minWidth: 180 }}>
                <Field label="Місто" required>
                  <Select placeholder="Оберіть місто" options={[{ value: "mariupol", label: "Маріуполь" }, { value: "donetsk", label: "Донецьк" }]} />
                </Field>
              </div>
              <div style={{ flex: 1, minWidth: 180 }}>
                <Field label="Тип">
                  <Select placeholder="Оберіть тип" options={[
                    { value: "kindergarten", label: "Дитсадок" }, { value: "school", label: "Школа" },
                    { value: "camp", label: "Табір" }, { value: "yard", label: "Двір" }, { value: "other", label: "Інше" },
                  ]} />
                </Field>
              </div>
            </div>
            <Field label="Роки">
              <TextInput placeholder="напр. 1998–2005" />
            </Field>
            <Field label="Опис" required>
              <Textarea placeholder="Опишіть, що саме шукаєте..." rows={4} />
            </Field>
            <Field label="Контактна пошта" required hint="Буде видно лише в цьому запиті">
              <TextInput type="email" placeholder="ви@пошта.com" />
            </Field>
            <div>
              <Button variant="primary">Опублікувати запит</Button>
            </div>
          </div>
        )}

        <div style={{ marginTop: "var(--space-6)" }}>
          <FilterBar city={city} onCityChange={(e) => setCity(e.target.value)} showSort={false} />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 20 }}>
          {requests.map((r) => (
            <LostRequestCard key={r.author} {...r} onClick={() => onNavigate("lost-detail")} />
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
}
