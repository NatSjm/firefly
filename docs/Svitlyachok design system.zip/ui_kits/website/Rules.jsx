function Rules({ onNavigate, loggedIn }) {
  const { Header, Footer } = window.Svitlyachok;
  const rules = [
    { title: "Доброзичливість понад усе", text: "Ми говоримо про дитинство і родину з теплом. Образи, приниження чи глузування тут не місце." },
    { title: "Без ненависті й політичних суперечок", text: "Спільнота об'єднує людей навколо спогадів, а не розділяє їх. Мова ворожнечі й провокації видаляються." },
    { title: "Повага до чужої історії", text: "У кожного своя пам'ять і свій біль. Не ставте під сумнів чужі спогади чи досвід." },
    { title: "Приватність за замовчуванням", text: "Публікуйте лише те, чим справді хочете поділитися. Приватні спогади бачите тільки ви." },
    { title: "Повідомляйте про порушення", text: "Якщо бачите контент, що порушує ці правила, скористайтеся кнопкою «Повідомити» — модератори розглянуть це." },
  ];
  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100%", background: "var(--bg-page)" }}>
      <Header loggedIn={loggedIn} userName="Оксана" onNavigate={onNavigate} />
      <div style={{ maxWidth: "var(--content-narrow)", margin: "0 auto", width: "100%", padding: "var(--space-16) var(--gutter)", flex: 1 }}>
        <h1 style={{ fontFamily: "var(--font-heading)", fontSize: "var(--text-h1)", marginBottom: 24 }}>Правила спільноти</h1>
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          {rules.map((r, i) => (
            <div key={r.title} style={{ display: "flex", gap: 16 }}>
              <div style={{
                width: 32, height: 32, borderRadius: "50%", background: "var(--primary-soft)", color: "var(--primary-hover)",
                display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 14, flexShrink: 0,
              }}>{i + 1}</div>
              <div>
                <div style={{ fontFamily: "var(--font-heading)", fontWeight: 600, fontSize: 17, marginBottom: 4 }}>{r.title}</div>
                <div style={{ fontSize: 14, color: "var(--text-secondary)", lineHeight: "var(--lh-body)" }}>{r.text}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
}
