# Svitlyachok — Website UI kit

An interactive click-through recreation of the Svitlyachok website: Homepage,
public Feed, personal Dashboard ("Мої світлячки"), a single Memory page,
"Lost Fireflies" (Загублені світлячки), About, and Community Rules.

Open `index.html` — it is a lightweight single-page app (state-based routing,
no real backend) that lets you click between all seven screens using the
header nav, hero CTAs, and card clicks, to see the design system's components
composed into real views. Toggle login state is stubbed to "logged in" by
default so dashboard/create affordances are visible.

Screens compose only the primitives in `../../components/` (Button, Badge,
MemoryCard, LostRequestCard, Header/Footer/MobileMenu, FilterBar, Inputs,
Message/Modal) — no one-off styles were invented for the kit.
