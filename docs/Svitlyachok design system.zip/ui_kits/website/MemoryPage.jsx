function MemoryPage({ onNavigate, loggedIn }) {
  const { Header, Footer, Badge, Textarea, Button } = window.Svitlyachok;
  const [comment, setComment] = React.useState("");
  const comments = [
    { author: "Ірина", text: "У нас теж такий був, ще й з дощечкою для стрибків через резинку.", date: "2 дні тому" },
    { author: "Максим", text: "Клас у класики, у нас на подвір'ї теж так грали до темна.", date: "1 день тому" },
  ];
  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100%", background: "var(--bg-page)" }}>
      <Header loggedIn={loggedIn} userName="Оксана" onNavigate={onNavigate} />
      <div style={{ maxWidth: "var(--content-narrow)", margin: "0 auto", width: "100%", padding: "var(--space-8) var(--gutter)", flex: 1 }}>
        <a onClick={() => onNavigate("feed")} style={{ fontSize: 13, color: "var(--text-tertiary)", cursor: "pointer", textDecoration: "none" }}>← до стрічки</a>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", margin: "var(--space-4) 0" }}>
          <Badge variant="topic" tone="moss">Київ</Badge>
          <Badge variant="topic" tone="amber">Дворові ігри</Badge>
          <span style={{ fontSize: 12, color: "var(--text-tertiary)", alignSelf: "center" }}>1994–1999</span>
        </div>

        <h1 style={{ fontFamily: "var(--font-heading)", fontSize: "var(--text-h1)", marginBottom: 8 }}>Двір на вулиці Шевченка</h1>
        <div style={{ fontSize: 13, color: "var(--text-tertiary)", marginBottom: 20 }}>Ірина · опубліковано 3 дні тому</div>

        <div style={{
          height: 260, borderRadius: "var(--radius-lg)", backgroundImage: "url('../../assets/placeholder-pattern.svg')",
          backgroundSize: "96px 96px", backgroundColor: "var(--bg-sunken)",
          display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 20,
        }}>
          <span style={{ fontFamily: "ui-monospace, monospace", fontSize: 12, color: "var(--text-tertiary)", background: "var(--bg-surface)", padding: "4px 10px", borderRadius: "var(--radius-sm)" }}>
            фото: двір, 1996
          </span>
        </div>

        <p style={{ fontSize: "var(--text-body-lg)", lineHeight: "var(--lh-body)", color: "var(--text-primary)" }}>
          Кожного вечора ми грали у класики, доки не темніло і не кликали додому.
          Крейда була на вагу золота — ми ділили один шматочок на весь двір.
          Іноді хтось приносив справжню гумку для резиночки, і це було ціле свято.
        </p>

        <div style={{ display: "flex", alignItems: "center", gap: 10, margin: "var(--space-8) 0", padding: "var(--space-4) 0", borderTop: "1px solid var(--border-subtle)", borderBottom: "1px solid var(--border-subtle)" }}>
          <Button variant="secondary" size="sm">🔥 Тепло · 9</Button>
          <span style={{ fontSize: 13, color: "var(--text-tertiary)" }}>2 коментарі</span>
        </div>

        <h2 style={{ fontFamily: "var(--font-heading)", fontSize: "var(--text-h4)", marginBottom: 14 }}>Коментарі</h2>
        <div style={{ display: "flex", flexDirection: "column", gap: 14, marginBottom: 20 }}>
          {comments.map((c) => (
            <div key={c.author} style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              <div style={{ fontSize: 13, fontWeight: 600 }}>{c.author} <span style={{ fontWeight: 400, color: "var(--text-tertiary)" }}>· {c.date}</span></div>
              <div style={{ fontSize: 14, color: "var(--text-secondary)", lineHeight: "var(--lh-body)" }}>{c.text}</div>
            </div>
          ))}
        </div>

        <Textarea placeholder="Залишити коментар..." rows={3} value={comment} onChange={(e) => setComment(e.target.value)} />
        <div style={{ marginTop: 10 }}>
          <Button variant="primary" size="sm">Надіслати</Button>
        </div>
      </div>
      <Footer />
    </div>
  );
}
