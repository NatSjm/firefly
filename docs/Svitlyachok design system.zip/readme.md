# Svitlyachok (Світлячок) — Design System

Svitlyachok ("firefly") is a Ukrainian-language web community for adults,
dedicated to childhood, family, and kindness. It is at once a personal memory
archive, a cozy community organized by topic and city, and a place to search
for childhood photos/videos lost to war or relocation.

This project is a **from-scratch design system** built for the brief and PRD
below — no existing brand, codebase, or Figma file was attached. Every visual
decision (palette, type, mark) originates here; there is no real "Svitlyachok"
company/logo to preserve or reference.

**Sources provided:**
- `product-brief.md` — narrative product brief (pasted into the conversation)
- `requirements.md` — numbered PRD (FR-*/NFR-*/TC-*/BC-* requirements)

No Figma link, codebase, or existing logo was provided.

## Index

- `styles.css` — global stylesheet entry point (imports everything below)
- `tokens/` — colors, typography, spacing, effects (radii/shadows), fonts, base resets
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand) shown in the Design System tab
- `assets/` — the firefly mark and a striped photo-placeholder pattern
- `components/` — reusable React primitives, grouped by concern:
  - `buttons/Button.jsx` — primary / secondary / ghost / danger / danger-solid
  - `inputs/Inputs.jsx` — `Field`, `TextInput` (text/email/password), `Textarea`, `Select`
  - `badges/Badge.jsx` — topic, privacy (public/private), Warmth
  - `cards/MemoryCard.jsx`, `cards/LostRequestCard.jsx`
  - `navigation/Navigation.jsx` — `Header`, `Footer`, `MobileMenu`
  - `filters/FilterBar.jsx` — city + topic + new/popular sort
  - `feedback/Feedback.jsx` — `Message` (success/warning/error), `Modal` (confirm/report)
- `ui_kits/website/` — interactive click-through of the whole site (Home, Feed,
  Dashboard, Memory page, Lost Fireflies, About, Rules) built from the
  components above
- `SKILL.md` — portable skill file for Claude Code / other agents

### Intentional additions
No source defined a component inventory, so the standard set above was
authored to size (per the brief's explicit component list). Nothing beyond
what the brief/PRD asked for was added.

## Content fundamentals

- **Language:** Ukrainian only (MVP). All copy in this system is written in
  Ukrainian; no hardcoded English strings in UI surfaces.
- **Tone:** calm, practical, warm — never hype, never clickbait, **no
  exclamation marks** anywhere in UI copy (per `BC-BRAND-01`). Compare:
  "Зберегти спогад" (save this memory), not "Збережи спогад просто зараз!".
- **Person:** direct second person for instructions and CTAs ("Розкажіть про
  дитинство", "Оберіть місто"), first person plural for the community's own
  voice ("Ми не женемося за лайками").
- **Empty states are gentle invitations, not guilt:** "Ще немає жодного
  спогаду. Почніть із простої історії — навіть кількох рядків достатньо,"
  not "You haven't created anything yet!"
- **No engagement-bait language.** Never "Не пропустіть", "Приєднуйтесь
  зараз", streaks, or urgency copy. Likes are called "Тепло" (Warmth), not
  "likes" — reframing the action as leaving warmth, not scoring points.
- **Errors are calm and actionable**, not alarmist: "Не вдалося зберегти.
  Спробуйте ще раз," never "Error!" or red-alert iconography.
- **Emoji:** not used in UI chrome or copy. The single 💬 glyph on comment
  counts and 🔥 on the Warmth button in the memory-page mockup are the only
  pictographic marks, standing in for icons the brief didn't specify assets
  for — swap for a proper icon set if one is adopted later.
- **Community rules language** is instructive, short, numbered — not legalese.

## Visual foundations

- **Palette:** warm, low-saturation neutrals (paper-cream light theme) with
  a single amber/gold "firefly glow" primary, a muted moss-green secondary
  accent (nature, yards, gardens), and a soft dusk-indigo used mostly for
  focus rings and the night theme. Built in `oklch()` so every accent family
  shares lightness/chroma and only varies by hue — this is why primary,
  moss, and dusk read as one coherent warm system rather than three random
  brand colors. Semantic success/warning/error follow the same
  lightness/chroma envelope so they never look "bolted on."
- **Contrast:** neutrals and the amber-600/700 primary were tuned to clear
  WCAG AA (4.5:1) for body text on `--bg-page`; verify any new color pairing
  before shipping (`NFR-A11Y-02`).
- **Dark mode:** a secondary "night" theme (`[data-theme="night"]`), not the
  default — fits the "light in the dark" firefly metaphor: same tokens,
  charcoal-dusk ground, and the amber primary is *brighter* (higher L/C) so
  it visually glows against the dark surface, echoing an actual firefly.
- **Typography:** Literata (serif, full Cyrillic) for display/headings —
  warm, literary, a little handwritten-feeling without being a script font —
  paired with Manrope (sans, full Cyrillic) for body copy and UI chrome.
  Loaded from Google Fonts CDN (`tokens/fonts.css`); no local font binaries
  were available to self-host.
- **Spacing:** 4px base unit, scale from 4 to 128px (`tokens/spacing.css`).
  Cards default to 24px internal padding and 16px internal gaps — generous,
  unhurried, never cramped.
- **Radii:** soft and cozy but not bubbly — 8 / 12 / 16 / 24px scale plus a
  pill radius for buttons and badges. Nothing sharp (0px) anywhere.
- **Shadows:** low elevation, warm-tinted (shadow color is a dark warm hue,
  not pure black) and diffuse — `shadow-sm/md/lg`. No hard drop shadows, no
  colored borders as a shadow substitute.
- **The one "loud" effect:** a soft amber glow (`--shadow-glow-sm/md`),
  reserved for the Warmth badge/button and the brand mark itself — the
  literal firefly-light moment. It never appears on ordinary buttons or
  cards, so it stays meaningful.
- **Borders:** hairline 1px, warm-neutral, low-contrast (`--border-subtle`
  for hairlines between sections, `--border-default` for card/input
  outlines, `--border-strong` for emphasis).
- **Cards:** soft shadow + 16px radius + hairline border, hover = slightly
  deeper shadow and a 2px lift (`translateY`), never a border-color swap or
  scale-up — calm motion only.
- **Imagery:** no real photography was provided. Photo slots use a subtle
  warm diagonal-stripe SVG placeholder (`assets/placeholder-pattern.svg`)
  with a small monospace label inside a chip (e.g. "фото: двір, 1996") so
  it's obvious what belongs there and the tone stays quiet, not a gray box.
- **Animation:** minimal — 120–200ms ease-standard transitions on hover/press
  only (background darken, soft lift, scale 0.98 on press). No bouncing, no
  auto-playing motion, no confetti. Calm is a feature, not a gap.
- **Hover / press states:** hover = background one step darker/lighter
  within the same token family (never a hue change); press = slight scale
  down (0.98). Disabled = 50% opacity, `not-allowed` cursor, no other change.
- **Layout rules:** header is sticky-capable top bar (logo left, nav
  center/right, auth state far right); content maxes out at 1200px
  (`--content-max`) with a narrower 720px column (`--content-narrow`) for
  reading-heavy pages (Memory, About, Rules).
- **Transparency/blur:** used once, deliberately — the modal scrim
  (`oklch(20% 0.02 60 / 45%)`), no blur. No frosted-glass panels elsewhere;
  the brand is paper-and-light, not glassy.

## Iconography

No icon system, icon font, or SVG icon set was provided or specified in the
brief. This system deliberately does **not** introduce one wholesale:

- Structural marks (privacy dot, Warmth glow-dot) are drawn as plain CSS
  circles — consistent with "never hand-roll SVG icons" guidance, and small
  enough not to need a real icon.
- Two placeholder pictographs are used as stand-ins where the brief implies
  an icon but specifies no asset: 💬 for comment counts and 🔥 on the Warmth
  action in the memory-page mock. These are flagged, not a system decision —
  swap for a proper icon set (e.g. Lucide/Heroicons, both CDN-available)
  once one is chosen.
- The **firefly mark** (`assets/firefly-mark.svg`) is an intentionally
  simple, abstract glow — a radial-gradient halo behind a small solid dot
  with one highlight — never a literal illustrated insect. Since Svitlyachok
  has no existing brand mark, this is an original, minimal starting point,
  not a recreation of anything.

## Caveats & open questions

- **Fonts** are CDN-loaded (Google Fonts), not self-hosted — no font
  binaries were available to copy in.
- **No logo/brand assets existed prior to this system** — the mark here is a
  first draft, meant to be replaced or refined once a real brand asset
  exists.
- Icon system is a placeholder (see Iconography) — recommend adopting a real
  icon set before build.
- Component set covers everything explicitly requested in the brief; ask if
  you'd like additions (e.g. Avatar, Tooltip, Toast) beyond that list.
