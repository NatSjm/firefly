import { ReactNode } from "react";

/**
 * @startingPoint section="Components" subtitle="Inline success/warning/error banner" viewport="700x70"
 */
export interface MessageProps {
  tone?: "success" | "warning" | "error";
  children: ReactNode;
  onDismiss?: () => void;
}

/**
 * @startingPoint section="Components" subtitle="Confirm-delete / report-content dialog" viewport="700x300"
 */
export interface ModalProps {
  open: boolean;
  title: string;
  children: ReactNode;
  onClose?: () => void;
  footer?: ReactNode;
}
