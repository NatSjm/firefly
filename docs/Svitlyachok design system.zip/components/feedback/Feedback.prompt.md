`Message` is an inline banner (success/warning/error). `Modal` is a centered dialog used for delete confirmation and reporting content.

```jsx
<Message tone="success">Спогад збережено.</Message>
<Message tone="error" onDismiss={close}>Не вдалося зберегти. Спробуйте ще раз.</Message>

<Modal open={confirmOpen} title="Видалити цей спогад?" onClose={close}
       footer={<>
         <Button variant="ghost" onClick={close}>Скасувати</Button>
         <Button variant="danger-solid" onClick={remove}>Видалити</Button>
       </>}>
  Цю дію не можна скасувати.
</Modal>
```

Tone colors are muted (soft tinted background + matching border/text), never a saturated alert red/green — consistent with the calm, non-alarmist voice.
