import { ReactNode, MouseEventHandler } from "react";

/**
 * @startingPoint section="Components" subtitle="Primary, secondary, ghost and danger actions" viewport="700x220"
 */
export interface ButtonProps {
  /** Visual style. "danger" is an outlined warning tone (e.g. Cancel in a delete-confirm); "danger-solid" is the committed destructive action. */
  variant?: "primary" | "secondary" | "ghost" | "danger" | "danger-solid";
  size?: "md" | "sm";
  /** Optional leading icon element. */
  icon?: ReactNode;
  disabled?: boolean;
  fullWidth?: boolean;
  children: ReactNode;
  onClick?: MouseEventHandler<HTMLButtonElement>;
  type?: "button" | "submit" | "reset";
}
