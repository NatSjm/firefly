A pill-shaped button with primary/secondary/ghost/danger variants, used for every call to action across Svitlyachok.

```jsx
<Button variant="primary" onClick={save}>Зберегти спогад</Button>
<Button variant="secondary">Переглянути стрічку</Button>
<Button variant="ghost" size="sm">Скасувати</Button>
<Button variant="danger-solid">Видалити спогад</Button>
```

Variants: `primary` (solid amber, main CTA), `secondary` (outlined neutral), `ghost` (no border, low emphasis, e.g. toolbar actions), `danger` (outlined red, used as the "not yet committed" side of a confirm dialog), `danger-solid` (solid red, the actual destructive commit). Sizes: `md` (default) and `sm`. Supports `icon`, `disabled`, `fullWidth`.
