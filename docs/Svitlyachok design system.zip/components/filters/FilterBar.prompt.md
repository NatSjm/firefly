A single filter row combining city select, topic select, and a new/popular sort toggle — used above the public feed and the Lost Fireflies list.

```jsx
<FilterBar city={city} onCityChange={e => setCity(e.target.value)}
           topic={topic} onTopicChange={e => setTopic(e.target.value)}
           sort={sort} onSortChange={setSort} />
```

Pass `showSort={false}` for lists (e.g. Lost Fireflies) that only need city/type filters, no sort.
