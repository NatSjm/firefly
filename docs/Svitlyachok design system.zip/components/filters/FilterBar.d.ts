/**
 * @startingPoint section="Components" subtitle="City, topic and new/popular sort" viewport="700x80"
 */
export interface FilterBarProps {
  city?: string;
  onCityChange?: (e: any) => void;
  topic?: string;
  onTopicChange?: (e: any) => void;
  sort?: "new" | "popular";
  onSortChange?: (value: "new" | "popular") => void;
  cities?: string[];
  topics?: string[];
  showSort?: boolean;
}
