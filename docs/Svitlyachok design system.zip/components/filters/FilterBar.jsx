import React from "react";
import { Select } from "../inputs/Inputs";

const CITIES = ["Київ", "Львів", "Одеса", "Харків", "Маріуполь", "Дніпро"];
const TOPICS = ["Океан Ельзи", "Бабусині рецепти", "Комп'ютерні ігри", "Тамагочі", "Дворові ігри"];

/**
 * FilterBar — city + topic + sort controls used atop the public feed and Lost Fireflies list.
 */
export function FilterBar({
  city, onCityChange,
  topic, onTopicChange,
  sort, onSortChange,
  cities = CITIES, topics = TOPICS,
  showSort = true,
}) {
  return (
    <div style={{
      display: "flex", flexWrap: "wrap", gap: 12, alignItems: "center",
      padding: "var(--space-4) 0", fontFamily: "var(--font-ui)",
    }}>
      <div style={{ minWidth: 180 }}>
        <Select
          value={city}
          onChange={onCityChange}
          placeholder="Усі міста"
          options={cities.map((c) => ({ value: c, label: c }))}
        />
      </div>
      <div style={{ minWidth: 200 }}>
        <Select
          value={topic}
          onChange={onTopicChange}
          placeholder="Усі теми"
          options={topics.map((t) => ({ value: t, label: t }))}
        />
      </div>
      {showSort && (
        <div style={{ display: "flex", marginLeft: "auto", background: "var(--bg-sunken)", borderRadius: "var(--radius-pill)", padding: 3, gap: 2 }}>
          {[{ v: "new", l: "Нові" }, { v: "popular", l: "Популярні" }].map((o) => (
            <button key={o.v} onClick={() => onSortChange && onSortChange(o.v)} style={{
              border: "none", cursor: "pointer", padding: "7px 16px", borderRadius: "var(--radius-pill)",
              fontSize: 13, fontWeight: 600,
              background: sort === o.v ? "var(--bg-surface)" : "transparent",
              color: sort === o.v ? "var(--text-primary)" : "var(--text-tertiary)",
              boxShadow: sort === o.v ? "var(--shadow-sm)" : "none",
            }}>{o.l}</button>
          ))}
        </div>
      )}
    </div>
  );
}
