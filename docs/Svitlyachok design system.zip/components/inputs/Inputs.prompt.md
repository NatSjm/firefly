Form field primitives: `Field` (label/hint/error wrapper), `TextInput` (text/email/password), `Textarea`, and `Select`.

```jsx
<Field label="Електронна пошта" required>
  <TextInput type="email" placeholder="ви@пошта.com" value={email} onChange={setEmail} />
</Field>

<Field label="Ваша історія" hint="Можна почати з кількох речень">
  <Textarea placeholder="Розкажіть про..." rows={6} />
</Field>

<Field label="Місто">
  <Select placeholder="Оберіть місто" options={[{value:"kyiv", label:"Київ"}]} />
</Field>
```

All fields share the same focus ring (soft amber), 12px radius, and a muted error state (red border + red helper text, never a harsh flash).
