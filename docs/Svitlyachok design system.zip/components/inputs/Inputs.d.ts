import { ReactNode, ChangeEventHandler } from "react";

/**
 * @startingPoint section="Components" subtitle="Label + helper/error wrapper shared by all fields" viewport="700x120"
 */
export interface FieldProps {
  label?: string;
  hint?: string;
  error?: string;
  required?: boolean;
  children: ReactNode;
}

export interface TextInputProps {
  type?: "text" | "email" | "password";
  placeholder?: string;
  value?: string;
  onChange?: ChangeEventHandler<HTMLInputElement>;
  error?: string;
  disabled?: boolean;
}

export interface TextareaProps {
  placeholder?: string;
  value?: string;
  onChange?: ChangeEventHandler<HTMLTextAreaElement>;
  rows?: number;
  error?: string;
  disabled?: boolean;
}

export interface SelectOption {
  value: string;
  label: string;
}

export interface SelectProps {
  value?: string;
  onChange?: ChangeEventHandler<HTMLSelectElement>;
  options: SelectOption[];
  placeholder?: string;
  error?: string;
  disabled?: boolean;
}
