import React from "react";
import { Badge } from "../badges/Badge";

const PATTERN = "url('../../assets/placeholder-pattern.svg')";

/**
 * MemoryCard — a story or recipe as it appears in the public feed / dashboard list.
 */
export function MemoryCard({
  title,
  excerpt,
  author,
  city,
  topic,
  photo = true,
  warmth = 0,
  comments = 0,
  privacy, // "public" | "private" | undefined (omit chip on public feed)
  onClick,
}) {
  const [hover, setHover] = React.useState(false);
  return (
    <article
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: "flex",
        flexDirection: "column",
        background: "var(--bg-surface)",
        border: "1px solid var(--border-default)",
        borderRadius: "var(--radius-lg)",
        overflow: "hidden",
        cursor: onClick ? "pointer" : "default",
        boxShadow: hover ? "var(--shadow-md)" : "var(--shadow-sm)",
        transform: hover ? "translateY(-2px)" : "none",
        transition: "box-shadow var(--duration-base) var(--ease-standard), transform var(--duration-base) var(--ease-standard)",
        fontFamily: "var(--font-ui)",
      }}
    >
      {photo && (
        <div style={{
          height: 160, backgroundImage: PATTERN, backgroundSize: "72px 72px",
          backgroundColor: "var(--bg-sunken)",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <span style={{ fontFamily: "ui-monospace, monospace", fontSize: 11, color: "var(--text-tertiary)", background: "var(--bg-surface)", padding: "3px 8px", borderRadius: "var(--radius-sm)" }}>
            фото спогаду
          </span>
        </div>
      )}
      <div style={{ padding: "var(--space-5)", display: "flex", flexDirection: "column", gap: 10 }}>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {topic && <Badge variant="topic" tone="amber">{topic}</Badge>}
          {city && <Badge variant="topic" tone="moss">{city}</Badge>}
          {privacy && <Badge variant={privacy === "public" ? "privacy-public" : "privacy-private"} />}
        </div>
        <h3 style={{ fontFamily: "var(--font-heading)", fontSize: 20, fontWeight: 600, color: "var(--text-primary)" }}>
          {title}
        </h3>
        <p style={{ fontSize: 14, color: "var(--text-secondary)", lineHeight: "var(--lh-body)", margin: 0 }}>
          {excerpt}
        </p>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 4, fontSize: 13, color: "var(--text-tertiary)" }}>
          <span>{author}</span>
          <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
            <Badge variant="warmth">{warmth}</Badge>
            <span>💬 {comments}</span>
          </div>
        </div>
      </div>
    </article>
  );
}
