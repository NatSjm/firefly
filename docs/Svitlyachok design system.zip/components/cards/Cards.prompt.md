Two card types. `MemoryCard` renders a story/recipe in the public feed or dashboard grid, with an optional photo placeholder, topic/city/privacy badges, and Warmth + comment counts. `LostRequestCard` renders a "Lost Fireflies" request.

```jsx
<MemoryCard
  title="Смак ірисок з бабусиної кухні"
  excerpt="Щоліта бабуся варила ці цукерки..."
  author="Оксана" city="Полтава" topic="Бабусині рецепти"
  warmth={12} comments={3} privacy="public"
/>

<LostRequestCard
  city="Маріуполь" type="school" years="1998–2005"
  description="Шукаю фото випускного 9-го класу, школа №33."
  author="Ігор" date="3 дні тому"
/>
```

Both use the same soft-lift hover (shadow + 2px translate), never a border-color change.
