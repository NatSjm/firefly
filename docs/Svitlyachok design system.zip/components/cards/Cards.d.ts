import { MouseEventHandler } from "react";

/**
 * @startingPoint section="Components" subtitle="Story/recipe card as it appears in the feed" viewport="700x420"
 */
export interface MemoryCardProps {
  title: string;
  excerpt: string;
  author: string;
  city?: string;
  topic?: string;
  photo?: boolean;
  warmth?: number;
  comments?: number;
  privacy?: "public" | "private";
  onClick?: MouseEventHandler;
}

/**
 * @startingPoint section="Components" subtitle="A Lost Fireflies request card" viewport="700x220"
 */
export interface LostRequestCardProps {
  city: string;
  type?: "kindergarten" | "school" | "camp" | "yard" | "other";
  years?: string;
  description: string;
  author: string;
  date: string;
  onClick?: MouseEventHandler;
}
