import React from "react";
import { Badge } from "../badges/Badge";

const TYPE_LABEL = {
  kindergarten: "Дитсадок",
  school: "Школа",
  camp: "Табір",
  yard: "Двір",
  other: "Інше",
};

/**
 * LostRequestCard — a request in the "Lost Fireflies" (Загублені світлячки) section.
 */
export function LostRequestCard({ city, type = "other", years, description, author, date, onClick }) {
  const [hover, setHover] = React.useState(false);
  return (
    <article
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: "flex", flexDirection: "column", gap: 10,
        background: "var(--bg-surface)",
        border: "1px solid var(--border-default)",
        borderRadius: "var(--radius-lg)",
        padding: "var(--space-5)",
        cursor: onClick ? "pointer" : "default",
        boxShadow: hover ? "var(--shadow-md)" : "var(--shadow-sm)",
        transition: "box-shadow var(--duration-base) var(--ease-standard)",
        fontFamily: "var(--font-ui)",
      }}
    >
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        <Badge variant="topic" tone="moss">{city}</Badge>
        <Badge variant="topic" tone="amber">{TYPE_LABEL[type] || type}</Badge>
        {years && <span style={{ fontSize: 12, color: "var(--text-tertiary)", alignSelf: "center" }}>{years}</span>}
      </div>
      <p style={{ fontSize: 15, color: "var(--text-primary)", lineHeight: "var(--lh-body)", margin: 0 }}>
        {description}
      </p>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, color: "var(--text-tertiary)" }}>
        <span>{author}</span>
        <span>{date}</span>
      </div>
    </article>
  );
}
