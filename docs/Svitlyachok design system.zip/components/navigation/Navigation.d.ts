/**
 * @startingPoint section="Components" subtitle="Top bar: logo, nav, login/user state" viewport="700x80"
 */
export interface HeaderProps {
  loggedIn?: boolean;
  userName?: string;
  onNavigate?: (key: string) => void;
  onLogin?: () => void;
  onMenuToggle?: () => void;
}

/**
 * @startingPoint section="Components" subtitle="Closing bar with rules/report links" viewport="700x140"
 */
export interface FooterProps {}

/**
 * @startingPoint section="Components" subtitle="Full-screen mobile nav" viewport="380x600"
 */
export interface MobileMenuProps {
  open: boolean;
  loggedIn?: boolean;
  onNavigate?: (key: string) => void;
  onClose?: () => void;
  onLogin?: () => void;
}
