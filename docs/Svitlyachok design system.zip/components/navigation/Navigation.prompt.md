`Header` (logo + nav + auth state), `Footer` (closing bar), and `MobileMenu` (full-screen nav for small breakpoints).

```jsx
<Header loggedIn userName="Оксана" onNavigate={go} />
<Footer />
<MobileMenu open={menuOpen} onNavigate={go} onClose={() => setMenuOpen(false)} />
```

Header switches from nav links (desktop/tablet) to a hamburger icon under 768px — the design assumes the consuming app hides `.header-nav-desktop` and shows the menu button via its own breakpoint CSS, since these components are inline-styled only.
