Small pill labels: topic tags, privacy state ("Публічно" / "Тільки я"), and the glowing "Warmth" (Тепло) count.

```jsx
<Badge variant="topic" tone="amber">Бабусині рецепти</Badge>
<Badge variant="topic" tone="moss">Київ</Badge>
<Badge variant="privacy-public" />
<Badge variant="privacy-private" />
<Badge variant="warmth">24</Badge>
```

Topic badges alternate between the amber and moss tone families so a row of mixed tags reads as varied, not flat. The `warmth` variant carries a small glowing dot — the only place glow appears outside the brand mark.
