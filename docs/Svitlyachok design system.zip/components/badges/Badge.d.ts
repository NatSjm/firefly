import { ReactNode } from "react";

/**
 * @startingPoint section="Components" subtitle="Topic, privacy and Warmth pill labels" viewport="700x140"
 */
export interface BadgeProps {
  variant?: "topic" | "privacy-public" | "privacy-private" | "warmth";
  /** Color family for a topic badge — alternate between the two so a feed of mixed topics doesn't read as one flat color. */
  tone?: "amber" | "moss";
  icon?: ReactNode;
  children?: ReactNode;
}
