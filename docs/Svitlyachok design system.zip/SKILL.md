---
name: svitlyachok-design
description: Use this skill to generate well-branded interfaces and assets for Svitlyachok (Світлячок), a Ukrainian-language web community about childhood, family, and kindness, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy
assets out and create static HTML files for the user to view. If working on
production code, you can copy assets and read the rules here to become an
expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they
want to build or design, ask some questions, and act as an expert designer
who outputs HTML artifacts _or_ production code, depending on the need.

Key things to remember about Svitlyachok:
- Ukrainian-language, calm, warm tone — no exclamation marks, no hype, no
  engagement-bait copy. Likes are called "Тепло" (Warmth).
- Warm paper-cream palette with an amber "firefly glow" primary; a night
  theme exists but is secondary/opt-in.
- Literata (serif, headings) + Manrope (sans, body/UI), both full Cyrillic.
- Soft rounded corners, low warm-tinted shadows, glow effect reserved only
  for the Warmth action and the brand mark — never used decoratively.
